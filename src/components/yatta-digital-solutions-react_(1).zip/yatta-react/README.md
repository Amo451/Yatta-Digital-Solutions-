# Yatta Digital Solutions — Website (React)

A React + Vite version of the Yatta Digital Solutions site: business technology consulting, Zoho,
AI agents, custom software, integrations, and training — with a consultative, problem-first "how
we work" section instead of upfront pricing, plus a blog built to scale to hundreds or thousands
of articles without slowing the site down.

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
```

Preview exactly what will be deployed:

```bash
npm run preview
```

## Project structure

```
src/
  main.jsx                 — React entry point (BrowserRouter, plain client render)
  index.css                — full design system (colors, type, layout, responsive rules)
  App.jsx                  — Header/Footer shell + route definitions
  data/
    content.js               — services, industries, process steps, hero diagram data
    postsIndex.js             — lightweight blog metadata ONLY (title, excerpt, date...) — no article bodies
  content/
    posts/<slug>.js           — one file per article, holding just that article's body
  pages/
    Home.jsx                  — the one-page site (Hero → Contact), unchanged
    Blog.jsx                   — blog listing + pagination ("/blog", "/blog/page/:page")
    BlogPost.jsx                — loads one post's content on demand ("/blog/:slug")
  components/
    Header.jsx, Footer.jsx    — nav/footer, both include a Blog link
    BlogPostView.jsx           — pure article renderer, shared by the client and the prerender script
    Hero.jsx, FlowDiagram.jsx, Reframe.jsx, Services.jsx, Industries.jsx, HowWeWork.jsx, About.jsx, Contact.jsx
scripts/
  prerender.mjs             — build-time static HTML generation (see below)
  clean-ssr-tmp.mjs         — removes the temporary SSR build folder after prerendering
```

Site content lives in `src/data/content.js`. Blog content is split across `src/data/postsIndex.js`
(metadata) and `src/content/posts/*.js` (bodies) — see below for why.

## Publishing a new article

1. Create `src/content/posts/your-slug.js`:

   ```js
   export default [
     { type: 'p', text: 'Opening paragraph.' },
     { type: 'h2', text: 'A subheading' },
     { type: 'ul', items: ['A bullet point', 'Another bullet point'] },
   ];
   ```

2. Add its metadata to the top of the `postsIndex` array in `src/data/postsIndex.js`:

   ```js
   {
     slug: 'your-slug',            // must match the filename above — becomes /blog/your-slug
     title: 'Your Article Title',
     excerpt: 'One or two sentences shown on the blog listing card.',
     category: 'AI Solutions',
     date: '2026-07-01',
     readTime: '5 min read',
   },
   ```

That's it — no CMS, no database, no rebuild logic to write.

## Why this scales to hundreds or thousands of posts

An earlier version of this blog kept every article's full text in one JS file that shipped to
every visitor on every page — fine for 4 posts, a real problem at 1,000. Two changes fixed that:

**1. Content is loaded per-article, not all at once.**
`src/data/postsIndex.js` holds only metadata (title, excerpt, date...) and stays small even at
huge scale. The actual body of each article lives in its own file under `src/content/posts/`, and
Vite code-splits each one into its own small chunk automatically (via `import.meta.glob` in
`BlogPost.jsx`). Opening one article downloads that article's ~2KB chunk — never the other 999.
Run `npm run build` and check the output: you'll see one small file per post next to the shared
app bundle, which stays a constant size no matter how many articles you add.

**2. Every page is pre-rendered to real static HTML at build time.**
`scripts/prerender.mjs` runs after `vite build` and renders the homepage, every paginated `/blog`
page, and every individual article to a real `index.html` with the actual content already inside
it — not just an empty shell waiting for JavaScript. That means:
- Fast first paint, since there's real content on screen before any JS runs.
- Real crawlable, indexable pages for Google — each with its own `<title>`, meta description, and
  canonical URL, pulled straight from that post's metadata.
- A generated `sitemap.xml` and `robots.txt` listing every page, so search engines can find your
  entire archive.

The client still boots as a normal React single-page app after that first paint (so navigating
between pages stays instant, no full reloads) — it just doesn't try to *hydrate* the prerendered
HTML, it replaces it with a fresh render. That's a deliberate, simple tradeoff: a very brief
extra client-side render on first load, in exchange for zero risk of the hydration-mismatch bugs
that come with trying to keep server and client markup byte-for-byte identical. At this scale,
that's the right tradeoff.

**Blog listing pagination** (`src/data/postsIndex.js` → `POSTS_PER_PAGE`, currently 12) means the
`/blog` page never has to render a list of 1,000 cards at once — it's prerendered page by page
(`/blog`, `/blog/page/2`, `/blog/page/3`, ...), each with its own static HTML and its own canonical
URL.

**Build time** grows roughly linearly with article count, since each one is a fast, synchronous
render — a few hundred posts adds seconds to the build, not minutes. If you get into the
thousands and build time becomes a real concern, that's the point to look at incremental/
cached builds rather than changing anything about the site itself.

### How the build works, step by step

`npm run build` runs:

1. `vite build` — builds the normal client app and JS bundles.
2. `vite build --ssr scripts/prerender.mjs` — compiles the prerender script (and the JSX
   components it imports) into plain Node-runnable JS, since Node can't execute `.jsx` files
   directly.
3. `node .ssr-tmp/prerender.js` — actually renders every page and writes it into `dist/`.
4. `node scripts/clean-ssr-tmp.mjs` — deletes the temporary compiled script.

You never need to run these steps individually — `npm run build` does all of it. `npm run dev`
is completely unaffected; prerendering only happens for production builds.

Before deploying, set your real domain so the sitemap, robots.txt, and canonical tags are correct:

```bash
SITE_URL=https://www.yourrealdomain.com npm run build
```

(It falls back to a placeholder domain if you don't set this — replace it before going live.)

## Deploying

This repo includes config for the two most common static hosts:
- `public/_redirects` — Netlify. Netlify natively resolves `/blog/your-slug` to
  `dist/blog/your-slug/index.html`, so no extra config is needed there; the catch-all rule is
  just a fallback for any path that isn't a prerendered page.
- `vercel.json` — Vercel, with `trailingSlash: true` set explicitly so `/blog/your-slug` reliably
  resolves to its prerendered directory, plus the same SPA fallback for anything not prerendered.

Other static hosts (GitHub Pages, S3/CloudFront, etc.) generally handle `folder/index.html` →
`/folder` and `/folder/` automatically; if you see a blank page or a 404 on a direct blog link
after deploying somewhere else, that host's "serve index.html for a directory" behavior is what to
check first.

## Before you launch

1. **Contact details** — in `src/components/Contact.jsx`, replace:
   - `hello@yattadigital.africa` with your real email
   - `https://wa.me/254700000000` with your real WhatsApp number (format: `https://wa.me/2547XXXXXXXX`)
2. **Contact form** — it currently only shows a confirmation message client-side; it doesn't send
   anywhere. Wire it to [Formspree](https://formspree.io), [EmailJS](https://www.emailjs.com/), or
   your own backend endpoint.
3. **Pricing / proposals** — intentionally not shown on the site. The "How we work" section leads
   with "tell us the problem" and moves to diagnosis, build, and support — pricing is something you
   raise once you understand the actual scope, not before.
4. **Favicon** — `public/favicon.svg` is a placeholder; swap in a real logo mark if you have one.
5. **SITE_URL** — set the environment variable described above before your first real deploy.

## Customizing the look

Every color, font, and spacing value lives at the top of `src/index.css` under `:root`. Change a
value there and it updates across every component.
