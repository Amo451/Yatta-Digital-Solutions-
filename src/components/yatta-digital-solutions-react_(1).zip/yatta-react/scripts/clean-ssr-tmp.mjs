import fs from 'node:fs';
fs.rmSync(new URL('../.ssr-tmp', import.meta.url), { recursive: true, force: true });
