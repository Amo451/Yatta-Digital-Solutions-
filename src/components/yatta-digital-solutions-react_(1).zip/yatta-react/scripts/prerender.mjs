// Runs after `vite build`. For every route we know about — the homepage,
// the blog index (with pagination), and every individual article — this
// renders the real page content to an HTML string and writes it into its
// own dist/<route>/index.html, using the already-built dist/index.html as
// a template for the surrounding <head>/scripts/styles.
//
// Why: with hundreds or thousands of blog posts, this is what keeps first
// paint fast and keeps every article crawlable by search engines, instead
// of shipping one big JS bundle that has to run before any content shows.
//
// The client does NOT hydrate this markup (see main.jsx) — it mounts a
// fresh React tree on load. That trades a tiny bit of upfront duplication
// for zero hydration-mismatch risk, which matters more at this stage.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { StaticRouter } from 'react-router';

import Header from '../src/components/Header.jsx';
import Footer from '../src/components/Footer.jsx';
import Home from '../src/pages/Home.jsx';
import Blog from '../src/pages/Blog.jsx';
import BlogPostView from '../src/components/BlogPostView.jsx';
import { postsIndex, POSTS_PER_PAGE } from '../src/data/postsIndex.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const distDir = path.join(root, 'dist');
const contentDir = path.join(root, 'src/content/posts');

const SITE_URL = process.env.SITE_URL || 'https://www.yattadigital.africa';
const SITE_NAME = 'Yatta Digital Solutions';

const template = fs.readFileSync(path.join(distDir, 'index.html'), 'utf-8');

function pageHtml(element, path_) {
  const app = React.createElement(
    StaticRouter,
    { location: path_ },
    React.createElement(
      React.Fragment,
      null,
      React.createElement('div', { className: 'grain', 'aria-hidden': 'true' }),
      React.createElement(Header),
      React.createElement('main', null, element),
      React.createElement(Footer)
    )
  );
  return renderToStaticMarkup(app);
}

function injectHead(html, { title, description, canonicalPath }) {
  let out = html;
  if (title) {
    out = out.replace(/<title>.*?<\/title>/s, `<title>${escapeHtml(title)}</title>`);
  }
  if (description) {
    out = out.replace(
      /(<meta name="description" content=")(.*?)(")/s,
      `$1${escapeHtml(description)}$3`
    );
  }
  const canonical = `<link rel="canonical" href="${SITE_URL}${canonicalPath}" />`;
  out = out.replace('</head>', `  ${canonical}\n  </head>`);
  return out;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function writePage(routePath, bodyHtml, head) {
  const withRoot = template.replace(
    '<div id="root"></div>',
    `<div id="root">${bodyHtml}</div>`
  );
  const finalHtml = injectHead(withRoot, { canonicalPath: routePath, ...head });

  const outDir =
    routePath === '/' ? distDir : path.join(distDir, routePath.replace(/^\//, ''));
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'index.html'), finalHtml);
}

async function loadPostContent(slug) {
  const mod = await import(path.join(contentDir, `${slug}.js`));
  return mod.default;
}

async function main() {
  const urls = [];

  // Home
  writePage('/', pageHtml(React.createElement(Home), '/'), {
    title: `${SITE_NAME} — Automate, Integrate, Scale`,
    description:
      'Yatta Digital Solutions helps African businesses automate operations, grow sales, and cut manual work through Zoho, custom software, systems integration and AI agents.',
  });
  urls.push('/');

  // Blog index + paginated pages
  const totalPages = Math.max(1, Math.ceil(postsIndex.length / POSTS_PER_PAGE));
  for (let page = 1; page <= totalPages; page++) {
    const routePath = page === 1 ? '/blog' : `/blog/page/${page}`;
    writePage(routePath, pageHtml(React.createElement(Blog), routePath), {
      title: page === 1 ? `Guides & Articles — ${SITE_NAME}` : `Guides & Articles (Page ${page}) — ${SITE_NAME}`,
      description:
        'Practical, no-hype guides on automation, Zoho, AI agents, and running technology projects in African businesses.',
    });
    urls.push(routePath);
  }

  // Every individual article
  for (const post of postsIndex) {
    const content = await loadPostContent(post.slug);
    const routePath = `/blog/${post.slug}`;
    writePage(
      routePath,
      pageHtml(React.createElement(BlogPostView, { post, content }), routePath),
      { title: `${post.title} — ${SITE_NAME}`, description: post.excerpt }
    );
    urls.push(routePath);
  }

  // sitemap.xml
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((u) => `  <url><loc>${SITE_URL}${u === '/' ? '' : u}</loc></url>`).join('\n')}
</urlset>
`;
  fs.writeFileSync(path.join(distDir, 'sitemap.xml'), sitemap);

  // robots.txt
  const robots = `User-agent: *\nAllow: /\n\nSitemap: ${SITE_URL}/sitemap.xml\n`;
  fs.writeFileSync(path.join(distDir, 'robots.txt'), robots);

  console.log(`Prerendered ${urls.length} pages (1 home, ${totalPages} blog index page(s), ${postsIndex.length} articles).`);
  console.log(`Wrote sitemap.xml and robots.txt using SITE_URL=${SITE_URL}`);
  console.log('Set the SITE_URL environment variable before building to use your real domain.');
}

main();
