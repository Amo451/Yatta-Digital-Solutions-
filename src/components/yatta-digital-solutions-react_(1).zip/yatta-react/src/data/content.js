export const services = [
  {
    tag: 'AUTO',
    title: 'Business Automation',
    desc: "Our flagship. CRM, sales pipelines, HR, accounting, inventory, support desks, project tracking, and approval workflows — rebuilt so people stop chasing paperwork.",
    points: [
      'Sales & CRM automation',
      'HR & approvals',
      'Accounting & inventory',
      'Customer support workflows',
    ],
    platforms: 'Zoho · Odoo · Microsoft 365 · Google Workspace',
  },
  {
    tag: 'ZOHO',
    title: 'Zoho Consulting',
    desc: 'Most businesses buy Zoho and never configure it properly. We implement, migrate, customise, and support it until it actually fits how your team works.',
    points: [
      'CRM · Books · Inventory · Desk',
      'Projects · People · Recruit',
      'Analytics · Zoho One · Creator · Flow',
      'Migration, training & API integration',
    ],
  },
  {
    tag: 'AI',
    title: 'AI Solutions',
    desc: 'Where we differentiate. Agents that qualify leads, answer customers at 2am, and let a manager ask a plain question and get a real answer from your own systems.',
    points: [
      'AI customer service (WhatsApp, Facebook, web, Instagram)',
      'AI sales agent — qualifies, books, quotes, follows up',
      'AI knowledge assistant, trained on your documents',
      'AI internal assistant — "show unpaid invoices over 500K"',
    ],
  },
  {
    tag: 'BUILD',
    title: 'Custom Software Development',
    desc: "When off-the-shelf isn't enough. Portals, dashboards, booking systems, school and hospital systems, internal tools — built to spec, not squeezed into a template.",
    points: [
      'Client & staff portals',
      'Dashboards & internal CRMs',
      'Booking & scheduling systems',
    ],
    platforms: 'React · Next.js · Node.js · Python',
  },
  {
    tag: 'LINK',
    title: 'Systems Integration',
    desc: "The quiet, expensive problem: good software that doesn't talk to other good software. We wire your website, CRM, accounting, payments and messaging into one flow.",
    points: [
      'Website ↔ CRM ↔ Books',
      'M-Pesa & payment integrations',
      'WhatsApp, Power BI, Sheets, Email, SMS',
    ],
  },
  {
    tag: 'TRAIN',
    title: 'Training & Adoption',
    desc: 'Software fails when nobody uses it properly. We train staff and management, write the manuals, record the tutorials, and stay through onboarding.',
    points: [
      'Staff & management training',
      'User manuals & video walkthroughs',
      'Ongoing onboarding support',
    ],
  },
];

export const industries = [
  'Construction',
  'Schools',
  'Hospitals',
  'NGOs',
  'Law firms',
  'Manufacturers',
  'Distributors',
  'Solar companies',
  'Insurance agencies',
  'Real estate firms',
  'Accounting firms',
  'SACCOs',
];

export const process = [
  {
    step: '01',
    title: 'Tell us the problem',
    desc: "No need to know which product or platform you need. Describe what's slow, manual, or held together with spreadsheets — we'll take it from there.",
  },
  {
    step: '02',
    title: 'We diagnose & propose',
    desc: 'We map how the work actually happens today, then come back with a clear plan: what we\'d build, what it replaces, and what changes for your team.',
  },
  {
    step: '03',
    title: 'We build & integrate',
    desc: 'Implementation, custom development, or integration work — scoped to your business, not a generic package.',
  },
  {
    step: '04',
    title: 'We train & stay on',
    desc: "We train your team, write the manuals, and stay close after launch so the system keeps fitting the business as it grows.",
  },
];

export const flowNodes = [
  { x: 190, y: 120, label: 'Website', tx: 190, ty: 102, path: 'M310,280 C270,230 230,170 190,120' },
  { x: 440, y: 110, label: 'Zoho CRM', tx: 440, ty: 92, path: 'M310,280 C360,230 400,170 440,110' },
  { x: 90, y: 250, label: 'Zoho Books', tx: 90, ty: 232, path: 'M310,280 C250,270 170,260 90,250' },
  { x: 530, y: 250, label: 'M-Pesa', tx: 530, ty: 232, path: 'M310,280 C370,270 450,260 530,250' },
  { x: 170, y: 410, label: 'WhatsApp', tx: 170, ty: 434, path: 'M310,280 C270,320 220,360 170,410' },
  { x: 450, y: 410, label: 'Power BI', tx: 450, ty: 434, path: 'M310,280 C350,320 400,360 450,410' },
  { x: 230, y: 460, label: 'Sheets', tx: 230, ty: 484, path: 'M310,280 C290,330 260,390 230,460' },
  { x: 390, y: 460, label: 'SMS / Email', tx: 390, ty: 484, path: 'M310,280 C330,330 360,390 390,460' },
];
