// Lightweight metadata only — no article bodies.
// This file is what powers the /blog listing and pagination, so it stays
// small even with hundreds or thousands of posts. Full article content is
// loaded on demand from src/content/posts/<slug>.js — see BlogPost.jsx.

export const POSTS_PER_PAGE = 12;

export const postsIndex = [
  {
    "slug": "zoho-vs-custom-crm",
    "title": "Zoho CRM vs. a Custom-Built CRM: How to Actually Decide",
    "excerpt": "Every SME eventually asks this question. Here's the framework we use with clients before recommending either one.",
    "category": "Zoho Consulting",
    "date": "2026-06-02",
    "readTime": "6 min read"
  },
  {
    "slug": "ai-sales-agent-reality-check",
    "title": "What an AI Sales Agent Can (and Can't) Do for Your Business",
    "excerpt": "AI sales agents are genuinely useful — but the marketing around them oversells what they replace. Here's a grounded look.",
    "category": "AI Solutions",
    "date": "2026-05-14",
    "readTime": "5 min read"
  },
  {
    "slug": "cost-of-disconnected-systems",
    "title": "The Real Cost of Systems That Don't Talk to Each Other",
    "excerpt": "Most businesses already have decent software. The problem is almost never the tools — it's the gaps between them.",
    "category": "Systems Integration",
    "date": "2026-04-22",
    "readTime": "5 min read"
  },
  {
    "slug": "getting-teams-to-use-new-software",
    "title": "How to Get Your Team to Actually Use New Software",
    "excerpt": "The software was never the hard part. Adoption is. Here's what separates rollouts that stick from the ones that quietly get abandoned.",
    "category": "Training & Adoption",
    "date": "2026-03-10",
    "readTime": "4 min read"
  }
];

export function getPostMeta(slug) {
  return postsIndex.find((p) => p.slug === slug);
}
