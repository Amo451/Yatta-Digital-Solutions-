import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getPostMeta } from '../data/postsIndex';
import BlogPostView from '../components/BlogPostView';

// Vite turns this into a map of { path: lazyImportFn }, one chunk per post.
// Nothing here is downloaded until the matching key is actually called —
// visiting one article never pulls in the other 999.
const contentLoaders = import.meta.glob('../content/posts/*.js');

export default function BlogPost() {
  const { slug } = useParams();
  const post = getPostMeta(slug);
  const [content, setContent] = useState(null);

  useEffect(() => {
    if (!post) return;
    setContent(null);
    const loader = contentLoaders[`../content/posts/${post.slug}.js`];
    if (!loader) return;
    let cancelled = false;
    loader().then((mod) => {
      if (!cancelled) setContent(mod.default);
    });
    return () => {
      cancelled = true;
    };
  }, [post]);

  if (!post) {
    return (
      <section className="blog-page">
        <div className="wrap post-not-found">
          <p className="section-kicker">Not found</p>
          <h1 className="blog-title">We couldn't find that article.</h1>
          <Link to="/blog" className="btn btn-primary">
            Back to all guides
          </Link>
        </div>
      </section>
    );
  }

  if (!content) {
    // Brief, near-instant state while this post's own small chunk loads.
    return (
      <section className="blog-page">
        <div className="wrap post-wrap">
          <p className="section-kicker">{post.category}</p>
          <h1 className="blog-title">{post.title}</h1>
        </div>
      </section>
    );
  }

  return <BlogPostView post={post} content={content} />;
}
