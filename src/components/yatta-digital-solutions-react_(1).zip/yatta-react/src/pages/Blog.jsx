import { Link, useParams } from 'react-router-dom';
import { postsIndex, POSTS_PER_PAGE } from '../data/postsIndex';

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

export default function Blog() {
  const { page: pageParam } = useParams();
  const totalPages = Math.max(1, Math.ceil(postsIndex.length / POSTS_PER_PAGE));
  const page = Math.min(Math.max(1, parseInt(pageParam || '1', 10) || 1), totalPages);

  const start = (page - 1) * POSTS_PER_PAGE;
  const pagePosts = postsIndex.slice(start, start + POSTS_PER_PAGE);

  return (
    <section className="blog-page">
      <div className="wrap">
        <p className="section-kicker">From the Yatta team</p>
        <h1 className="blog-title">Guides &amp; Articles</h1>
        <p className="blog-subtitle">
          Practical, no-hype writing on automation, Zoho, AI agents, and running technology
          projects in African businesses. No pitch — just what we've learned doing this work.
        </p>

        <div className="blog-grid">
          {pagePosts.map((post) => (
            <Link className="blog-card" to={`/blog/${post.slug}`} key={post.slug}>
              <p className="blog-card-tag">{post.category}</p>
              <h2>{post.title}</h2>
              <p className="blog-card-excerpt">{post.excerpt}</p>
              <p className="blog-card-meta">
                {formatDate(post.date)} · {post.readTime}
              </p>
            </Link>
          ))}
        </div>

        {totalPages > 1 && (
          <nav className="blog-pagination" aria-label="Blog pagination">
            <Link
              to={page - 1 <= 1 ? '/blog' : `/blog/page/${page - 1}`}
              className={`btn btn-ghost-light ${page === 1 ? 'is-disabled' : ''}`}
              aria-disabled={page === 1}
              tabIndex={page === 1 ? -1 : undefined}
            >
              ← Newer
            </Link>
            <span className="blog-pagination-status">
              Page {page} of {totalPages}
            </span>
            <Link
              to={`/blog/page/${page + 1}`}
              className={`btn btn-ghost-light ${page === totalPages ? 'is-disabled' : ''}`}
              aria-disabled={page === totalPages}
              tabIndex={page === totalPages ? -1 : undefined}
            >
              Older →
            </Link>
          </nav>
        )}
      </div>
    </section>
  );
}
