import Hero from '../components/Hero';
import Reframe from '../components/Reframe';
import Services from '../components/Services';
import Industries from '../components/Industries';
import HowWeWork from '../components/HowWeWork';
import About from '../components/About';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Hero />
      <Reframe />
      <Services />
      <Industries />
      <HowWeWork />
      <About />
      <Contact />
    </>
  );
}
