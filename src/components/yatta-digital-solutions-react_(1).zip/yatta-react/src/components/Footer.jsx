const links = [
  { href: '/#services', label: 'Services' },
  { href: '/#industries', label: 'Industries' },
  { href: '/#how-we-work', label: 'How we work' },
  { href: '/#about', label: 'About' },
  { href: '/blog', label: 'Blog' },
  { href: '/#contact', label: 'Contact' },
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="wrap footer-inner">
        <div className="footer-brand">
          <span className="brand-text">
            Yatta <em>Digital Solutions</em>
          </span>
          <p>Automate, integrate, scale.</p>
        </div>
        <nav className="footer-nav">
          {links.map((l) => (
            <a key={l.href} href={l.href}>
              {l.label}
            </a>
          ))}
        </nav>
        <p className="footer-copy">© {year} Yatta Digital Solutions. Nairobi, Kenya.</p>
      </div>
    </footer>
  );
}
