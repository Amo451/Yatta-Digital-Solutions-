import { useState } from 'react';
import { Link } from 'react-router-dom';

const links = [
  { href: '/#services', label: 'Services' },
  { href: '/#industries', label: 'Industries' },
  { href: '/#how-we-work', label: 'How we work' },
  { href: '/#about', label: 'About' },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header" id="top">
      <div className="wrap header-inner">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 40 40" width="34" height="34">
              <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeWidth="2" />
              <path
                d="M20 8 L20 20 L30 26"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="20" cy="20" r="3" fill="currentColor" />
            </svg>
          </span>
          <span className="brand-text">
            Yatta <em>Digital Solutions</em>
          </span>
        </Link>

        <nav className={`main-nav ${open ? 'open' : ''}`} id="main-nav">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}>
              {l.label}
            </a>
          ))}
          <Link to="/blog" onClick={() => setOpen(false)}>
            Blog
          </Link>
          <a href="/#contact" className="nav-cta" onClick={() => setOpen(false)}>
            Talk to us
          </a>
        </nav>

        <button
          className="nav-toggle"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </header>
  );
}
