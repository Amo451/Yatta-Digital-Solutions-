import { useState } from 'react';

const initialForm = {
  name: '',
  company: '',
  email: '',
  topic: 'Business Automation',
  message: '',
};

const topics = [
  'Business Automation',
  'Zoho Consulting',
  'AI Solutions',
  'Custom Software',
  'Systems Integration',
  'Training',
  'Not sure yet',
];

export default function Contact() {
  const [form, setForm] = useState(initialForm);
  const [note, setNote] = useState('');

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    setNote(
      `Thanks, ${form.name || 'there'}. This is a demo form — connect it to an email service (e.g. Formspree, EmailJS) or your own backend to receive real submissions.`
    );
    setForm(initialForm);
  }

  return (
    <section className="contact" id="contact">
      <div className="wrap contact-inner">
        <div className="contact-copy">
          <p className="section-kicker">Let's talk</p>
          <h2>Tell us what's slow, manual, or held together with spreadsheets.</h2>
          <p>We'll come back with a plan, not a sales pitch.</p>
          <div className="contact-details">
            <a href="mailto:hello@yattadigital.africa">hello@yattadigital.africa</a>
            <a href="https://wa.me/254700000000" target="_blank" rel="noopener noreferrer">
              WhatsApp: +254 700 000 000
            </a>
            <span>Nairobi, Kenya · serving East Africa</span>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Name
            <input
              type="text"
              name="name"
              required
              placeholder="Your name"
              value={form.name}
              onChange={handleChange}
            />
          </label>
          <label>
            Company
            <input
              type="text"
              name="company"
              placeholder="Business name"
              value={form.company}
              onChange={handleChange}
            />
          </label>
          <label>
            Email
            <input
              type="email"
              name="email"
              required
              placeholder="you@company.com"
              value={form.email}
              onChange={handleChange}
            />
          </label>
          <label>
            What do you need help with?
            <select name="topic" value={form.topic} onChange={handleChange}>
              {topics.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          <label>
            Tell us more
            <textarea
              name="message"
              rows="4"
              placeholder="What's manual, slow, or disconnected right now?"
              value={form.message}
              onChange={handleChange}
            />
          </label>
          <button type="submit" className="btn btn-primary">
            Send message
          </button>
          <p className="form-note" role="status">
            {note}
          </p>
        </form>
      </div>
    </section>
  );
}
