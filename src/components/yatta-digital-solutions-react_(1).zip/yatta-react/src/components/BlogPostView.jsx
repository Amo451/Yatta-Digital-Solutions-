import { Link } from 'react-router-dom';

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function Block({ block }) {
  if (block.type === 'h2') return <h2>{block.text}</h2>;
  if (block.type === 'ul') {
    return (
      <ul>
        {block.items.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    );
  }
  return <p>{block.text}</p>;
}

// Pure, synchronous — takes already-resolved data as props.
// Used by BlogPost.jsx (client, after the content chunk loads) and by
// scripts/prerender.mjs (build time, where content is imported directly).
export default function BlogPostView({ post, content }) {
  return (
    <section className="blog-page">
      <div className="wrap post-wrap">
        <Link to="/blog" className="back-link">
          ← Back to all guides
        </Link>
        <p className="section-kicker">{post.category}</p>
        <h1 className="blog-title">{post.title}</h1>
        <p className="blog-card-meta">
          {formatDate(post.date)} · {post.readTime}
        </p>

        <article className="post-body">
          {content.map((block, i) => (
            <Block block={block} key={i} />
          ))}
        </article>

        <div className="post-footer">
          <Link to="/blog" className="btn btn-ghost-light">
            ← Back to all guides
          </Link>
          <Link to="/#contact" className="btn btn-primary">
            Talk to us about this
          </Link>
        </div>
      </div>
    </section>
  );
}
