import { services } from '../data/content';

export default function Services() {
  return (
    <section className="services" id="services">
      <div className="wrap">
        <p className="section-kicker">Six divisions, one team</p>
        <h2>Every process a growing business runs into, somewhere in here.</h2>

        <div className="service-grid">
          {services.map((s) => (
            <article className="service-card" key={s.title}>
              <p className="service-tag">{s.tag}</p>
              <h3>{s.title}</h3>
              <p className="service-desc">{s.desc}</p>
              <ul className="service-list">
                {s.points.map((pt) => (
                  <li key={pt}>{pt}</li>
                ))}
              </ul>
              {s.platforms && <p className="service-platforms">{s.platforms}</p>}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
