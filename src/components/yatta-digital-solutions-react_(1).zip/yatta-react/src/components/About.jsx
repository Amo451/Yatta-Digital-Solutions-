export default function About() {
  return (
    <section className="about" id="about">
      <div className="wrap about-inner">
        <p className="section-kicker">Why Yatta</p>
        <h2>Business technology, not just Zoho tickets.</h2>
        <p className="about-body">
          "Yatta" is a business we built on a simple bet: African SMEs don't need more software,
          they need the software they already have to work together, and a team that understands
          both the systems and the AI layer on top of them. We sit across web development,
          automation, integrations, and AI agents — so the recommendation you get is the right one
          for your business, not just the one platform we happen to sell.
        </p>
      </div>
    </section>
  );
}
