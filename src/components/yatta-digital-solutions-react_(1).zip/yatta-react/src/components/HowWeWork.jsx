import { process } from '../data/content';

export default function HowWeWork() {
  return (
    <section className="engagement" id="how-we-work">
      <div className="wrap">
        <p className="section-kicker">How an engagement starts</p>
        <h2>You bring the problem. We figure out the right fix.</h2>
        <p className="engagement-lede">
          No need to arrive knowing whether you need Zoho, custom software, or an AI agent — that's
          our job to work out with you.
        </p>

        <div className="process-grid">
          {process.map((p) => (
            <div className="process-card" key={p.step}>
              <p className="process-step">{p.step}</p>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
