export default function Reframe() {
  return (
    <section className="reframe">
      <div className="wrap reframe-inner">
        <p className="section-kicker">What we actually do</p>
        <div className="reframe-cols">
          <div className="reframe-col old">
            <p className="reframe-label">What people expect us to say</p>
            <p className="reframe-line strike">&ldquo;We implement Zoho.&rdquo;</p>
          </div>
          <div className="reframe-col new">
            <p className="reframe-label">What's true</p>
            <p className="reframe-line">
              &ldquo;We help African businesses automate operations, increase sales, and
              eliminate manual work — through software, AI, and business process
              automation.&rdquo;
            </p>
          </div>
        </div>
        <p className="reframe-note">
          Zoho is one platform we're deeply fluent in. It's a tool in the kit, not the ceiling on
          what you can ask us to solve.
        </p>
      </div>
    </section>
  );
}
