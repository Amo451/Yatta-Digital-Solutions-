import { flowNodes } from '../data/content';

const HUB = { x: 310, y: 280 };

export default function FlowDiagram() {
  return (
    <svg viewBox="0 0 620 560" className="flow-svg" aria-hidden="true">
      <g className="spokes" stroke="var(--line-on-dark)" strokeWidth="1.6" fill="none">
        {flowNodes.map((n, i) => (
          <path key={i} d={n.path} />
        ))}
      </g>

      {flowNodes.map((n, i) => (
        <circle
          key={i}
          r="4.5"
          fill={i % 2 === 0 ? 'var(--ochre)' : 'var(--teal-bright)'}
          className="pulse"
        >
          <animateMotion dur="4.5s" repeatCount="indefinite" begin={`${i * 0.5}s`} path={n.path} />
        </circle>
      ))}

      <circle cx={HUB.x} cy={HUB.y} r="46" fill="var(--ink-2)" stroke="var(--ochre)" strokeWidth="1.6" />
      <text x={HUB.x} y={HUB.y - 5} textAnchor="middle" className="hub-label">
        YATTA
      </text>
      <text x={HUB.x} y={HUB.y + 13} textAnchor="middle" className="hub-sub">
        connects it
      </text>

      {flowNodes.map((n, i) => (
        <g className="node" key={i}>
          <circle cx={n.x} cy={n.y} r="5" fill="var(--paper)" />
          <text x={n.tx} y={n.ty} textAnchor="middle">
            {n.label}
          </text>
        </g>
      ))}
    </svg>
  );
}
