import FlowDiagram from './FlowDiagram';

export default function Hero() {
  return (
    <section className="hero">
      <div className="wrap hero-grid">
        <div className="hero-copy">
          <p className="eyebrow">Business technology consulting — Nairobi &amp; East Africa</p>
          <h1>
            Software that finally
            <br />
            <span className="hl">talks to itself.</span>
          </h1>
          <p className="hero-lede">
            We help African businesses automate operations, grow sales, and eliminate manual work
            — through software, AI, and business process automation. Zoho is one of our tools. It
            isn't the whole story.
          </p>
          <div className="hero-actions">
            <a href="#contact" className="btn btn-primary">
              Tell us your problem
            </a>
            <a href="#services" className="btn btn-ghost">
              See what we build
            </a>
          </div>
          <ul className="hero-proof">
            <li>
              <span>6</span> service divisions
            </li>
            <li>
              <span>11+</span> Zoho products
            </li>
            <li>
              <span>1</span> team that owns the whole stack
            </li>
          </ul>
        </div>

        <div className="hero-visual">
          <FlowDiagram />
        </div>
      </div>
    </section>
  );
}
