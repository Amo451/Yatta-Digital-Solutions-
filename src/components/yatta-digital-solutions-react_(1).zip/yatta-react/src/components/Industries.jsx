import { industries } from '../data/content';

export default function Industries() {
  return (
    <section className="industries" id="industries">
      <div className="wrap industries-inner">
        <div className="industries-copy">
          <p className="section-kicker">Who we build for</p>
          <h2>We go deep in a few industries, not wide across all of them.</h2>
          <p>
            The more specialised we get, the fewer surprises there are on your project — because
            we've usually solved a version of this problem before.
          </p>
        </div>
        <ul className="chip-grid">
          {industries.map((i) => (
            <li key={i}>{i}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
