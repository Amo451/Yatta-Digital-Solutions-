export default [
  {
    "type": "p",
    "text": "This question comes up in almost every first conversation we have with a growing business: should we buy Zoho CRM, or should we build something custom? The honest answer is that most businesses ask it too early — before they've actually mapped out what their sales process looks like today. Once that's clear, the decision usually makes itself."
  },
  {
    "type": "h2",
    "text": "Start with the process, not the software"
  },
  {
    "type": "p",
    "text": "Before comparing platforms, write down how a lead actually becomes a paying customer in your business right now. Where does it come from? Who touches it, in what order? What information do they need at each step, and where does that information currently live — a notebook, a spreadsheet, someone's head? This exercise alone reveals more than any product demo will."
  },
  {
    "type": "h2",
    "text": "When Zoho CRM is the right call"
  },
  {
    "type": "ul",
    "items": [
      "Your sales process is fairly standard — leads, quotes, follow-ups, deals won or lost.",
      "You want to move fast. Zoho CRM can be configured and running inside weeks, not months.",
      "You already use, or plan to use, other Zoho products (Books, Desk, Inventory) and want them talking to each other natively.",
      "Your budget needs to go further on training and adoption than on development."
    ]
  },
  {
    "type": "h2",
    "text": "When custom software earns its cost"
  },
  {
    "type": "ul",
    "items": [
      "Your workflow has a genuinely unusual shape — multi-stage approvals, industry-specific compliance steps, or logic that doesn't map to a standard sales pipeline.",
      "You need the CRM to be the system of record for something Zoho doesn't model well, like project-based billing tied to physical site visits.",
      "You expect to outgrow off-the-shelf limits within a year or two and want to own the roadmap outright."
    ]
  },
  {
    "type": "h2",
    "text": "The middle path most people miss"
  },
  {
    "type": "p",
    "text": "It's rarely all-or-nothing. Many of our clients run Zoho CRM as the backbone — contacts, deals, communication history — and we build a small custom layer on top for the one workflow that's genuinely unique to them, connected through Zoho's API. You get speed where speed is available, and precision where it matters."
  },
  {
    "type": "p",
    "text": "If you're stuck deciding, the fastest way through it is to map the process first and bring that map to whoever is advising you — including us. A twenty-minute conversation with a clear process in hand beats months of comparing feature lists."
  }
];
