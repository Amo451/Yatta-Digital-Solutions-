export default [
  {
    "type": "p",
    "text": "\"AI sales agent\" gets used to describe everything from a simple auto-responder to a fully autonomous closer. That gap in expectations is where most disappointment comes from. Here's what a well-built one actually does, and where a human still needs to step in."
  },
  {
    "type": "h2",
    "text": "What it handles well"
  },
  {
    "type": "ul",
    "items": [
      "Answering the same questions your team answers ten times a day — pricing ranges, availability, product specs — instantly, on WhatsApp, your website, or Instagram.",
      "Qualifying leads by asking the right follow-up questions before a human ever gets involved, so your team only spends time on leads worth chasing.",
      "Booking appointments directly into your calendar without back-and-forth messages.",
      "Following up automatically with leads who go quiet, at intervals a busy salesperson would never remember to keep.",
      "Sending quotations from a template the moment someone asks, instead of a day later."
    ]
  },
  {
    "type": "h2",
    "text": "Where it still needs a human"
  },
  {
    "type": "ul",
    "items": [
      "Negotiating price or terms on anything non-standard — the agent should recognise this and hand off, not improvise.",
      "Reading a relationship. Long-standing clients often expect a familiar voice, not a bot, even a well-trained one.",
      "Handling complaints or anything emotionally charged. This is a hand-off moment, every time.",
      "Final judgment calls on unusual, high-value deals."
    ]
  },
  {
    "type": "h2",
    "text": "The part nobody mentions: it needs feeding"
  },
  {
    "type": "p",
    "text": "An AI sales agent is only as good as what it knows about your business. That means real product details, real pricing logic, and real examples of good and bad conversations. The setup work is less about the AI model and more about getting your own information organised well enough to hand over. Businesses that treat this seriously get an agent that sounds like them. Businesses that skip it get a generic chatbot with your logo on it."
  },
  {
    "type": "p",
    "text": "If you're evaluating whether this is worth it, the honest test is volume: if your team is already answering the same handful of questions dozens of times a week, an AI agent will pay for itself quickly. If your sales process is mostly a handful of high-touch relationship deals a month, the return is smaller — though the follow-up and reminder side still tends to help."
  }
];
