export default [
  {
    "type": "p",
    "text": "We rarely walk into a business with no software at all. Almost everyone has a website, an accounting tool, a way of messaging customers, and some kind of spreadsheet system holding the rest together. The problem is never a lack of tools. It's that none of them are talking to each other — and that silence has a cost, even when it doesn't show up on any invoice."
  },
  {
    "type": "h2",
    "text": "Where the cost actually shows up"
  },
  {
    "type": "ul",
    "items": [
      "Someone retyping the same customer details into three different systems, and occasionally getting one wrong.",
      "Sales closing a deal that finance doesn't find out about until the client asks where the invoice is.",
      "Stock numbers on the website that don't match the warehouse, because nobody updates both.",
      "A manager who can't get a straight answer to \"how much do we owe suppliers right now\" without calling three people.",
      "Payments landing in M-Pesa that take a day or two to be reflected anywhere else."
    ]
  },
  {
    "type": "p",
    "text": "None of these look like emergencies individually. Together, they quietly consume hours every week and produce the kind of small errors that erode a client's trust in your operation."
  },
  {
    "type": "h2",
    "text": "Why this gets worse as you grow, not better"
  },
  {
    "type": "p",
    "text": "A five-person team can paper over disconnected systems because everyone just talks to each other constantly. At twenty or fifty people, that informal coordination breaks down, and the gaps between systems turn into the actual source of operational chaos — usually right around the time growth should be making things easier, not harder."
  },
  {
    "type": "h2",
    "text": "What \"integration\" actually means in practice"
  },
  {
    "type": "p",
    "text": "It's rarely one big project. It's usually a handful of specific, well-defined connections: your website sending new leads straight into your CRM; your CRM pushing won deals into your accounting system automatically; M-Pesa payments reconciling against invoices without anyone touching a spreadsheet; a dashboard that pulls numbers from two or three systems into one view a manager can trust."
  },
  {
    "type": "p",
    "text": "The businesses that get the most value out of this don't try to connect everything at once. They pick the one gap that's costing the most time or causing the most errors, fix that connection first, and expand from there."
  }
];
