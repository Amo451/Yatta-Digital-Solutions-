export default [
  {
    "type": "p",
    "text": "We've implemented systems that were, on paper, exactly what the business needed — and watched staff quietly go back to the old spreadsheet three weeks later. The software wasn't the problem. The rollout was."
  },
  {
    "type": "h2",
    "text": "Why good software gets abandoned"
  },
  {
    "type": "p",
    "text": "People don't resist new tools because they're difficult. They resist them because switching costs them time today in exchange for a benefit they're told they'll see later — and \"later\" is a hard sell to someone with a full inbox. If the new system doesn't visibly make someone's specific job easier within the first week, it loses."
  },
  {
    "type": "h2",
    "text": "What actually works"
  },
  {
    "type": "ul",
    "items": [
      "Train by role, not by feature list. A salesperson and an accountant should never sit through the same training session.",
      "Launch with real data, not a demo account. People trust a system once they see their own customers and numbers inside it.",
      "Find the one task the new system does noticeably faster than the old way, and lead with that in training — not the full feature tour.",
      "Put a person, not a manual, on standby for the first two weeks. Most adoption problems die in the first ten minutes of confusion, if someone is there to answer it.",
      "Review usage after 30 days, honestly. If a feature isn't being used, find out why before assuming it's a training gap — sometimes it's a sign the workflow itself needs adjusting."
    ]
  },
  {
    "type": "h2",
    "text": "The uncomfortable truth about ownership"
  },
  {
    "type": "p",
    "text": "Adoption sticks best when someone inside the business — not the vendor, not us — owns it. That doesn't mean a manager checking compliance. It means someone who can answer \"how do I do X in the new system\" faster than a Google search, and who has the standing to say \"we're not going back to the old way.\" Part of our job during onboarding is helping identify and equip that person, because the system we hand over on launch day is rarely the same one that's still in use a year later — and that's exactly how it should be."
  }
];
